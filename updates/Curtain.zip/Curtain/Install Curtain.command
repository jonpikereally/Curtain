#!/bin/bash
# Curtain installer: copies the app to /Applications and launches it.
cd "$(dirname "$0")"
echo "Installing Curtain…"
pkill -x Curtain 2>/dev/null; sleep 0.5
rm -rf /Applications/Curtain.app
ditto --norsrc Curtain.app /Applications/Curtain.app
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine /Applications/Curtain.app 2>/dev/null
codesign --force --sign - /Applications/Curtain.app
tccutil reset Accessibility com.jonpike.curtain >/dev/null 2>&1
tccutil reset ScreenCapture com.jonpike.curtain >/dev/null 2>&1
open /Applications/Curtain.app
echo
echo "Done! Look for the ‹ arrow in your menu bar."
echo "Grant Accessibility when asked (System Settings → Privacy & Security → Accessibility)."
echo "Optional: Screen Recording, so the popout shows the real icons."
