Curtain v1.20 — a menu bar hider for macOS (14+)
https://github.com/jonpikereally/Curtain

INSTALL
1. Double-click "Install Curtain.command".
   If macOS blocks it: right-click it, choose Open, then Open again.
2. Grant Accessibility when prompted (System Settings → Privacy & Security →
   Accessibility). Curtain needs it to read the menu bar.
3. Optional: Screen Recording, so the popout shows the real icons.

USE
• Click the ‹ arrow to see hidden icons (popout or on the bar; choose in Settings).
  Option-click does the other one.
• Right-click the arrow for Settings, Check for Updates and Quit.
• Show all icons, then hold ⌘ and drag an icon across the ≡ divider to hide or keep it.

PRIVACY
Everything stays on your Mac. The only thing Curtain fetches from the internet is a
small version file from the GitHub repo above, to see whether an update exists.
